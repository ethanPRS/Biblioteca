import React, { createContext, useContext, useState } from 'react';

export interface Book {
  id: number;
  title: string;
  author: string;
  cover: string;
  category: string;
  status: 'Disponible' | 'Prestado' | string;
  location: string;
  totalCopies: number;
  availableCopies: number;
  isbn: string;
  editorial: string;
  edition: string;
  price: number;
  finePerDay: number;
  synopsis: string;
  format: 'Físico' | 'Digital' | 'Ambos';
  physicalCopies?: number; // Solo para libros físicos o ambos
  pdfUrl?: string; // Solo para libros digitales o ambos
  availabilityStatus: 'Disponible para préstamo a casa' | 'Disponible para uso interno' | 'Dado de baja';
}

export const CATEGORIES = ["Negocios", "Ficción", "Desarrollo Personal", "Ciencias", "Historia", "Biografía"];

const INITIAL_BOOKS: Book[] = [
  { 
    id: 1, 
    title: 'La psicología del dinero', 
    author: 'Morgan Housel', 
    cover: 'https://images.unsplash.com/photo-1769490315625-6e669d53e698?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYm9vayUyMGNvdmVyfGVufDF8fHx8MTc3MjcxNjk3NHww&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Negocios', 
    status: 'Disponible',
    location: 'Estante A-12',
    totalCopies: 5,
    availableCopies: 4,
    isbn: '978-0857197689',
    editorial: 'Harriman House',
    edition: '1ra Edición',
    price: 350,
    finePerDay: 10,
    synopsis: 'Un análisis fascinante sobre cómo pensamos acerca del dinero y cómo tomar mejores decisiones financieras.',
    format: 'Físico',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 2, 
    title: 'Company of One', 
    author: 'Paul Jarvis', 
    cover: 'https://images.unsplash.com/photo-1706885655567-33a37db62835?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGdyYXBoaWMlMjBkZXNpZ24lMjBwb3N0ZXJ8ZW58MXx8fHwxNzcyNjI1OTE5fDA&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Negocios', 
    status: 'Prestado',
    location: 'En circulación',
    totalCopies: 1,
    availableCopies: 0,
    isbn: '978-0241380222',
    editorial: 'Penguin Books',
    edition: '1ra Edición',
    price: 280,
    finePerDay: 10,
    synopsis: 'Una guía sobre cómo crear un negocio exitoso manteniéndolo pequeño e independiente.',
    format: 'Físico',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 3, 
    title: 'El gran Gatsby', 
    author: 'F. Scott Fitzgerald', 
    cover: 'https://images.unsplash.com/photo-1770581939371-326fc1537f10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0eXBvZ3JhcGh5JTIwcG9zdGVyJTIwZGVzaWdufGVufDF8fHx8MTc3MjczNDQzMnww&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Ficción', 
    status: 'Disponible',
    location: 'Estante B-04',
    totalCopies: 3,
    availableCopies: 3,
    isbn: '978-0743273565',
    editorial: 'Scribner',
    edition: '2da Edición',
    price: 220,
    finePerDay: 10,
    synopsis: 'Una obra maestra de la literatura americana sobre el sueño americano y la decadencia moral.',
    format: 'Físico',
    availabilityStatus: 'Disponible para uso interno'
  },
  { 
    id: 4, 
    title: 'Breve historia del tiempo', 
    author: 'Stephen Hawking', 
    cover: 'https://images.unsplash.com/photo-1659640764406-416f70e32bec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBnZW9tZXRyaWMlMjBwYXR0ZXJuJTIwYmFja2dyb3VuZHxlbnwxfHx8fDE3NzI3NDk5NjV8MA&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Ciencias', 
    status: 'Disponible',
    location: 'Estante C-01',
    totalCopies: 2,
    availableCopies: 2,
    isbn: '978-0553380163',
    editorial: 'Bantam',
    edition: '10ma Edición',
    price: 380,
    finePerDay: 10,
    synopsis: 'Una exploración accesible de los conceptos más complejos de la física moderna.',
    format: 'Físico',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 5, 
    title: 'Sapiens', 
    author: 'Yuval Noah Harari', 
    cover: 'https://images.unsplash.com/photo-1611576673788-a954e01092d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBzYXBpZW5zfGVufDF8fHx8MTc3Mjc1MDA0N3ww&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Historia', 
    status: 'Disponible',
    location: 'Estante D-15',
    totalCopies: 4,
    availableCopies: 3,
    isbn: '978-0062316097',
    editorial: 'Harper',
    edition: '1ra Edición',
    price: 420,
    finePerDay: 10,
    synopsis: 'Una fascinante historia de la humanidad desde la Edad de Piedra hasta el presente.',
    format: 'Digital',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 6, 
    title: 'Steve Jobs', 
    author: 'Walter Isaacson', 
    cover: 'https://images.unsplash.com/photo-1569769107543-e0f61bab8e02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBzdGV2ZSUyMGpvYnN8ZW58MXx8fHwxNzcyNzUwMDQ3fDA&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Biografía', 
    status: 'Disponible',
    location: 'Estante E-09',
    totalCopies: 2,
    availableCopies: 2,
    isbn: '978-1451648539',
    editorial: 'Simon & Schuster',
    edition: '1ra Edición',
    price: 450,
    finePerDay: 10,
    synopsis: 'La biografía definitiva de Steve Jobs, basada en más de cuarenta entrevistas exclusivas.',
    format: 'Físico',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 7, 
    title: 'Pensar rápido, pensar despacio', 
    author: 'Daniel Kahneman', 
    cover: 'https://images.unsplash.com/photo-1762719299395-deeb7e92775c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY292ZXIlMjBwc3ljaG9sb2d5fGVufDF8fHx8MTc3Mjc1MDA1Mnww&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Ciencias', 
    status: 'Prestado',
    location: 'En circulación',
    totalCopies: 1,
    availableCopies: 0,
    isbn: '978-0374533557',
    editorial: 'Farrar, Straus and Giroux',
    edition: '1ra Edición',
    price: 390,
    finePerDay: 10,
    synopsis: 'Una exploración revolucionaria de los dos sistemas que rigen nuestro pensamiento.',
    format: 'Físico',
    availabilityStatus: 'Disponible para préstamo a casa'
  },
  { 
    id: 8, 
    title: '1984', 
    author: 'George Orwell', 
    cover: 'https://images.unsplash.com/photo-1602128110234-2d11c0aaadfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc3MjcxNDY5MHww&ixlib=rb-4.1.0&q=80&w=400', 
    category: 'Ficción', 
    status: 'Disponible',
    location: 'Estante B-11',
    totalCopies: 6,
    availableCopies: 6,
    isbn: '978-0451524935',
    editorial: 'Signet Classic',
    edition: '3ra Edición',
    price: 250,
    finePerDay: 10,
    synopsis: 'Una visión distópica del futuro donde el Gran Hermano todo lo ve y controla.',
    format: 'Físico',
    availabilityStatus: 'Dado de baja'
  }
];

interface BookContextType {
  books: Book[];
  addBook: (book: Omit<Book, 'id'>) => void;
  updateBook: (id: number, book: Partial<Book>) => void;
  deleteBook: (id: number) => void;
}

const BookContext = createContext<BookContextType | null>(null);

export function BookProvider({ children }: { children: React.ReactNode }) {
  const [books, setBooks] = useState<Book[]>(INITIAL_BOOKS);

  const addBook = (book: Omit<Book, 'id'>) => {
    setBooks([{ ...book, id: Date.now() }, ...books]);
  };

  const updateBook = (id: number, updatedBook: Partial<Book>) => {
    setBooks(books.map(b => b.id === id ? { ...b, ...updatedBook } : b));
  };

  const deleteBook = (id: number) => {
    setBooks(books.filter(b => b.id !== id));
  };

  return (
    <BookContext.Provider value={{ books, addBook, updateBook, deleteBook }}>
      {children}
    </BookContext.Provider>
  );
}

export const useBooks = () => {
  const context = useContext(BookContext);
  if (!context) throw new Error('useBooks must be used within BookProvider');
  return context;
};